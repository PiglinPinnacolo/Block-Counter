package io.pinnacolo.blockcounter;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Tracks only changes initiated by the local player's interaction controller. */
public final class CounterTracker {
    private record Pending(BlockPos pos, BlockState before, boolean place, int dueTick) {}
    private final List<Pending> pending = new ArrayList<>();
    private int ticks;
    private ClientLevel previousLevel;
    public void clear() { pending.clear(); }
    public void startPlacement(BlockPos hit, BlockPos adjacent, ClientLevel level) {
        if (level == null) return;
        enqueue(hit, level, true);
        if (!adjacent.equals(hit)) enqueue(adjacent, level, true);
    }
    public void startBreaking(BlockPos pos, ClientLevel level) {
        if (level != null && !level.getBlockState(pos).isAir()) enqueue(pos, level, false);
    }
    private void enqueue(BlockPos pos, ClientLevel level, boolean place) {
        // A successful local action normally creates an immediate prediction;
        // the later world state is checked for an observed transition.
        pending.add(new Pending(pos.immutable(), level.getBlockState(pos), place, ticks + 5));
    }
    public void tick(Minecraft minecraft) {
        ticks++;
        ClientLevel level = minecraft.level;
        if (level != previousLevel) { clear(); previousLevel = level; }
        if (level == null || BlockCounter.CONFIG == null) return;
        boolean dirty = false;
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (ticks < p.dueTick()) continue;
            it.remove();
            BlockState after = level.getBlockState(p.pos());
            boolean changed = !after.equals(p.before());
            if (p.place() && changed && !after.isAir() && (p.before().isAir() || after.getBlock() != p.before().getBlock())) {
                BlockCounter.CONFIG.placed++;
                dirty = true;
            } else if (!p.place() && !p.before().isAir() && after.isAir()) {
                BlockCounter.CONFIG.broken++;
                dirty = true;
            }
        }
        if (dirty) BlockCounter.CONFIG.save();
    }
}
