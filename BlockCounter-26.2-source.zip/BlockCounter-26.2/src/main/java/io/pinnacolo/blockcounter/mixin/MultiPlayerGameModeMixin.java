package io.pinnacolo.blockcounter.mixin;

import io.pinnacolo.blockcounter.BlockCounter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "useItemOn", at = @At("HEAD"))
    private void bc$place(LocalPlayer player, InteractionHand hand, BlockHitResult hit, CallbackInfoReturnable<?> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !(player.getItemInHand(hand).getItem() instanceof BlockItem)) return;
        BlockPos pos = hit.getBlockPos();
        BlockCounter.TRACKER.startPlacement(pos, pos.relative(hit.getDirection()), mc.level);
    }
    @Inject(method = "destroyBlock", at = @At("HEAD"))
    private void bc$break(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) BlockCounter.TRACKER.startBreaking(pos, mc.level);
    }
}
