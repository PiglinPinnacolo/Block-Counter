package io.pinnacolo.blockcounter;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.DeltaTracker;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

public final class BlockCounter implements ClientModInitializer {
    public static CounterConfig CONFIG;
    public static final CounterTracker TRACKER = new CounterTracker();
    @Override public void onInitializeClient() {
        CONFIG = CounterConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(client -> TRACKER.tick(client));
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("blockcounter", "counter_hud"), BlockCounter::render);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, context) -> dispatcher.register(
            literal("blockcounter")
                .executes(ctx -> feedback(Component.translatable("blockcounter.help")))
                .then(literal("reset").executes(ctx -> { CONFIG.placed = 0; CONFIG.broken = 0; TRACKER.clear(); CONFIG.save(); return feedback(Component.translatable("blockcounter.reset")); }))
                .then(literal("show").executes(ctx -> { CONFIG.visible = true; CONFIG.save(); return feedback(Component.literal("HUD: ON")); }))
                .then(literal("hide").executes(ctx -> { CONFIG.visible = false; CONFIG.save(); return feedback(Component.literal("HUD: OFF")); }))
                .then(literal("x").then(argument("pixels", IntegerArgumentType.integer(-10000, 10000)).executes(ctx -> { CONFIG.x = IntegerArgumentType.getInteger(ctx, "pixels"); CONFIG.save(); return feedback(Component.literal("X: " + CONFIG.x)); })))
                .then(literal("y").then(argument("pixels", IntegerArgumentType.integer(-10000, 10000)).executes(ctx -> { CONFIG.y = IntegerArgumentType.getInteger(ctx, "pixels"); CONFIG.save(); return feedback(Component.literal("Y: " + CONFIG.y)); })))
                .then(literal("scale").then(argument("percent", IntegerArgumentType.integer(50, 400)).executes(ctx -> { CONFIG.scale = IntegerArgumentType.getInteger(ctx, "percent"); CONFIG.save(); return feedback(Component.literal("Scale: " + CONFIG.scale + "%")); })))
        ));
    }
    private static int feedback(Component c) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(c, false);
        return 1;
    }
    private static void render(GuiGraphicsExtractor graphics, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || !CONFIG.visible || mc.options.hideGui) return;
        float scale = CONFIG.scale / 100.0f;
        String a = Component.translatable("blockcounter.placed").getString() + ": " + CONFIG.placed;
        String b = Component.translatable("blockcounter.broken").getString() + ": " + CONFIG.broken;
        String c = Component.translatable("blockcounter.total").getString() + ": " + (CONFIG.placed + CONFIG.broken);
        int widest = Math.max(mc.font.width(a), Math.max(mc.font.width(b), mc.font.width(c)));
        graphics.pose().pushMatrix();
        graphics.pose().translate(CONFIG.x, CONFIG.y);
        graphics.pose().scale(scale, scale);
        graphics.fill(0, 0, widest + 12, 38, 0x90000000);
        graphics.text(mc.font, a, 6, 4, 0xFF7CE3A1);
        graphics.text(mc.font, b, 6, 15, 0xFFFFA66E);
        graphics.text(mc.font, c, 6, 26, 0xFFFFFFFF);
        graphics.pose().popMatrix();
    }
}
