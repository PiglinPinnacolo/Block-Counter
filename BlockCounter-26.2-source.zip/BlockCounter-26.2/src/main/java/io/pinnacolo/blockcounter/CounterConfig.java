package io.pinnacolo.blockcounter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class CounterConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("blockcounter.json");
    public long placed = 0;
    public long broken = 0;
    public int x = 8;
    public int y = 8;
    public int scale = 100; // percentage
    public boolean visible = true;
    public static CounterConfig load() {
        try {
            if (Files.exists(PATH)) {
                CounterConfig c = GSON.fromJson(Files.readString(PATH, StandardCharsets.UTF_8), CounterConfig.class);
                if (c != null) return c;
            }
        } catch (Exception e) { System.err.println("[BlockCounter] Could not read config: " + e); }
        return new CounterConfig();
    }
    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (Exception e) { System.err.println("[BlockCounter] Could not save config: " + e); }
    }
}
